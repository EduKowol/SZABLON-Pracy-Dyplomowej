# Wariant internetowy

Ta paczka jest przeznaczona do Prism, Overleaf lub podobnego edytora. Nie zawiera
lokalnego pliku `latexmkrc`. Po imporcie ustaw:

- dokument główny: `main.tex`;
- kompilator: LuaLaTeX.

Katalogiem plików pomocniczych zarządza platforma internetowa.
