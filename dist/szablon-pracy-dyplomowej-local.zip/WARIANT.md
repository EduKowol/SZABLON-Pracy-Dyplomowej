# Wariant lokalny

Ta paczka zawiera `latexmkrc` i jest przeznaczona do kompilacji na komputerze.

Na Windows zainstaluj MiKTeX oraz interpreter Perl (np. Strawberry Perl),
ponieważ `latexmk` jest skryptem napisanym w Perlu. Sprawdź środowisko:

```text
perl --version
latexmk -v
```

Kompiluj ją poleceniem:

```text
latexmk main.tex
```

LuaLaTeX oraz katalog `build/` zostaną wybrane automatycznie.
