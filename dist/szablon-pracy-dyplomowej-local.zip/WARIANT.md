# Wariant lokalny

Ta paczka zawiera `latexmkrc`. Kompiluj ją poleceniem:

```text
latexmk main.tex
```

LuaLaTeX oraz katalog `build/` zostaną wybrane automatycznie.
